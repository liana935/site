// firebase-config.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";


const firebaseConfig = {
  apiKey: "AIzaSyDezO84_PsAOVK-XRLkXNIKoIOXYKwe1j0",
  authDomain: "site-9401a.firebaseapp.com",
  projectId: "site-9401a",
  storageBucket: "site-9401a.firebasestorage.app",
  messagingSenderId: "527151963091",
  appId: "1:527151963091:web:609bd31be1532fccaa6d26",
  measurementId: "G-0NRGYT2HG9"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);