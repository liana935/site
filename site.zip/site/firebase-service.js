// firebase-service.js
import { auth, db } from './firebase-config.js';
import { 
    onAuthStateChanged, 
    signInWithEmailAndPassword, 
    createUserWithEmailAndPassword, 
    signOut 
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { 
    doc, setDoc, getDoc, updateDoc, collection, getDocs, addDoc
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

class FirebaseService {
    constructor() {
        this.currentUser = null;
        this.initAuthListener();
        this.initProducts();
    }

    initAuthListener() {
        onAuthStateChanged(auth, (user) => {
            console.log('Auth state changed:', user);
            this.currentUser = user;
            if (typeof window.handleAuthChange === 'function') {
                window.handleAuthChange(user);
            }
        });
    }

    async initProducts() {
        try {
            const products = await this.getProducts();
            console.log('Products in database:', products.length);
            if (products.length === 0) {
                console.log('No products found, creating demo products...');
                await this.createDemoProducts();
            }
        } catch (error) {
            console.error('Error initializing products:', error);
        }
    }

    async signUp(email, password) {
        try {
            console.log('Signing up user:', email);
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            await this.createUserProfile(userCredential.user.uid, email);
            console.log('User signed up successfully');
            return userCredential;
        } catch (error) {
            console.error('Sign up error:', error);
            throw new Error(this.getAuthErrorMessage(error.code));
        }
    }

    async signIn(email, password) {
        try {
            console.log('Signing in user:', email);
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            console.log('User signed in successfully');
            return userCredential;
        } catch (error) {
            console.error('Sign in error:', error);
            throw new Error(this.getAuthErrorMessage(error.code));
        }
    }

    async signOut() {
        try {
            console.log('Signing out user');
            await signOut(auth);
            console.log('User signed out successfully');
        } catch (error) {
            console.error('Sign out error:', error);
            throw new Error('Ошибка при выходе: ' + error.message);
        }
    }

    async createUserProfile(uid, email) {
        try {
            console.log('Creating user profile for:', uid);
            await setDoc(doc(db, 'users', uid), {
                email: email,
                createdAt: new Date(),
                cart: []
            });
            console.log('User profile created successfully');
        } catch (error) {
            console.error('Error creating user profile:', error);
        }
    }

    async getProducts() {
        try {
            console.log('Getting products from Firestore...');
            const querySnapshot = await getDocs(collection(db, 'products'));
            const products = querySnapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            }));
            console.log('Products retrieved:', products.length);

            // If no products in Firebase, create demo products
            if (products.length === 0) {
                console.log('No products in Firebase, creating demo products...');
                await this.createDemoProducts();
                // Return demo products after creation
                return this.getDemoProducts();
            }

            return products;
        } catch (error) {
            console.error('Error getting products from Firebase, using local demo products:', error);
            // Fallback to local demo products if Firebase fails
            return this.getDemoProducts();
        }
    }

    async searchProducts(searchTerm) {
        try {
            console.log('Searching products for:', searchTerm);
            const products = await this.getProducts();
            const term = searchTerm.toLowerCase().trim();
            
            const results = products.filter(product => {
                const searchText = `${product.name} ${product.description} ${product.category} ${product.brand || ''}`.toLowerCase();
                return searchText.includes(term);
            });
            
            console.log('Search results:', results.length);
            return results;
        } catch (error) {
            console.error('Error searching products:', error);
            return [];
        }
    }

    getDemoProducts() {
        return [
            {
                id: "demo-1",
                name: "Корм для кошек \"Премиум\"",
                description: "Сбалансированное питание для вашего питомца с витаминами и минералами",
                price: "1 299 ₽",
                fullPrice: 1299,
                category: "кошки",
                image: "images/korm1.png",
                brand: "PremiumPet",
                stock: 50,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-2",
                name: "Лежанка для кошки \"Уют\"",
                description: "Мягкая лежанка с бортиками для комфортного сна",
                price: "2 199 ₽",
                fullPrice: 2199,
                category: "кошки",
                image: "images/leganka.png",
                brand: "ComfortZone",
                stock: 25,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-3",
                name: "Когтеточка \"Дерево\"",
                description: "Прочная когтеточка из натурального дерева",
                price: "3 499 ₽",
                fullPrice: 3499,
                category: "кошки",
                image: "images/kogti1.png",
                brand: "NaturalWood",
                stock: 15,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-4",
                name: "Переноска \"Комфорт\"",
                description: "Пластиковая переноска с вентиляцией",
                price: "1 899 ₽",
                fullPrice: 1899,
                category: "кошки",
                image: "images/perenoska.png",
                brand: "SafeTravel",
                stock: 12,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-5",
                name: "Игрушка \"Мышь\"",
                description: "Интерактивная игрушка с кошачьей мятой",
                price: "299 ₽",
                fullPrice: 299,
                category: "кошки",
                image: "images/mish1.png",
                brand: "CatFun",
                stock: 30,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-6",
                name: "Игрушка для собак \"Прочная\"",
                description: "Из натурального каучука, безопасно для зубов",
                price: "899 ₽",
                fullPrice: 899,
                category: "собаки",
                image: "images/kost1.png",
                brand: "StrongBite",
                stock: 40,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-7",
                name: "Ошейник для собаки \"Комфорт\"",
                description: "Кожаный ошейник с гравировкой",
                price: "1 499 ₽",
                fullPrice: 1499,
                category: "собаки",
                image: "images/osheinik.png",
                brand: "LeatherComfort",
                stock: 20,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-8",
                name: "Корм для собак \"Энергия\"",
                description: "Для активных собак крупных пород",
                price: "2 199 ₽",
                fullPrice: 2199,
                category: "собаки",
                image: "images/kormdog.png",
                brand: "EnergyPet",
                stock: 35,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-9",
                name: "Поводок \"Прогулка\"",
                description: "Прочный поводок длиной 3 метра",
                price: "799 ₽",
                fullPrice: 799,
                category: "собаки",
                image: "images/povodok.png",
                brand: "WalkEasy",
                stock: 25,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-10",
                name: "Миска керамическая",
                description: "Керамическая миска с антискользящим дном",
                price: "599 ₽",
                fullPrice: 599,
                category: "собаки",
                image: "images/miska.png",
                brand: "CeramicPet",
                stock: 45,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-11",
                name: "Аквариум 50л с подсветкой",
                description: "Комплект с фильтром и освещением",
                price: "4 599 ₽",
                fullPrice: 4599,
                category: "рыбы",
                image: "images/akvarium.png",
                brand: "AquaWorld",
                stock: 10,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-12",
                name: "Корм для рыб \"Универсальный\"",
                description: "Сбалансированный корм для пресноводных рыб",
                price: "399 ₽",
                fullPrice: 399,
                category: "рыбы",
                image: "images/kormfish.png",
                brand: "FishFood",
                stock: 60,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-13",
                name: "Фильтр внутренний",
                description: "Мощный фильтр для аквариумов до 100л",
                price: "1 299 ₽",
                fullPrice: 1299,
                category: "рыбы",
                image: "images/filtr.png",
                brand: "AquaFilter",
                stock: 18,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-14",
                name: "Обогреватель 100Вт",
                description: "Автоматический обогреватель с термостатом",
                price: "899 ₽",
                fullPrice: 899,
                category: "рыбы",
                image: "images/obogrevatel.png",
                brand: "WarmAqua",
                stock: 22,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-15",
                name: "Набор декораций",
                description: "Камни, коряги и растения для оформления",
                price: "1 999 ₽",
                fullPrice: 1999,
                category: "рыбы",
                image: "images/ukrasheniya.png",
                brand: "AquaDecor",
                stock: 15,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-16",
                name: "Корм для попугаев \"Витамин\"",
                description: "Обогащенный витаминами корм",
                price: "799 ₽",
                fullPrice: 799,
                category: "грызуны",
                image: "images/kormpopugay.png",
                brand: "BirdVit",
                stock: 28,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-17",
                name: "Клетка для хомяка",
                description: "Просторная клетка с аксессуарами",
                price: "2 499 ₽",
                fullPrice: 2499,
                category: "грызуны",
                image: "images/kletka.png",
                brand: "HamsterHome",
                stock: 8,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-18",
                name: "Беговое колесо \"Спорт\"",
                description: "Бесшумное колесо для грызунов",
                price: "899 ₽",
                fullPrice: 899,
                category: "грызуны",
                image: "images/koleso.png",
                brand: "SilentRun",
                stock: 20,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-19",
                name: "Домик деревянный",
                description: "Уютный домик из натурального дерева",
                price: "599 ₽",
                fullPrice: 599,
                category: "грызуны",
                image: "images/domik.png",
                brand: "WoodHouse",
                stock: 15,
                isActive: true,
                createdAt: new Date()
            },
            {
                id: "demo-20",
                name: "Автопоилка 200мл",
                description: "Капельная поилка с креплением",
                price: "299 ₽",
                fullPrice: 299,
                category: "грызуны",
                image: "images/poilka.png",
                brand: "AutoWater",
                stock: 32,
                isActive: true,
                createdAt: new Date()
            }
        ];
    }

    async createDemoProducts() {
        const demoProducts = this.getDemoProducts();

        try {
            console.log('Creating demo products...');
            for (const product of demoProducts) {
                await addDoc(collection(db, 'products'), product);
            }
            console.log('Demo products created successfully');
        } catch (error) {
            console.error('Error creating demo products:', error);
        }
    }

    async getCart() {
        console.log('Getting cart for user:', this.currentUser?.email);
        
        if (!this.currentUser) {
            const localCart = this.getLocalCart();
            console.log('Using local cart (guest):', localCart);
            return localCart;
        }
        
        try {
            const docRef = doc(db, 'users', this.currentUser.uid);
            const docSnap = await getDoc(docRef);
            
            if (docSnap.exists()) {
                const cart = docSnap.data().cart || [];
                console.log('Cart from Firebase:', cart);
                return cart;
            } else {
                console.log('User document does not exist, returning empty cart');
                return [];
            }
        } catch (error) {
            console.error('Error getting cart from Firebase:', error);
            const localCart = this.getLocalCart();
            console.log('Falling back to local cart:', localCart);
            return localCart;
        }
    }

    async addToCart(product) {
        console.log('Adding to cart:', product);
        
        if (!this.currentUser) {
            console.log('No user, using local cart');
            return this.addToLocalCart(product);
        }

        try {
            const userRef = doc(db, 'users', this.currentUser.uid);
            const userDoc = await getDoc(userRef);
            const cart = userDoc.exists() ? userDoc.data().cart || [] : [];
            
            console.log('Current cart before addition:', cart);
            
            const existingItemIndex = cart.findIndex(item => item.id === product.id);
            
            if (existingItemIndex > -1) {
                cart[existingItemIndex].quantity += 1;
                console.log('Increased quantity for existing item');
            } else {
                cart.push({
                    ...product,
                    quantity: 1,
                    addedAt: new Date()
                });
                console.log('Added new item to cart');
            }
            
            await updateDoc(userRef, { cart });
            console.log('Cart updated in Firebase:', cart);
            return cart;
        } catch (error) {
            console.error('Error adding to cart in Firebase:', error);
            throw new Error('Ошибка при добавлении в корзину: ' + error.message);
        }
    }

    async removeFromCart(productId) {
        console.log('Removing from cart:', productId);
        
        if (!this.currentUser) {
            console.log('No user, using local cart');
            return this.removeFromLocalCart(productId);
        }

        try {
            const userRef = doc(db, 'users', this.currentUser.uid);
            const userDoc = await getDoc(userRef);
            const cart = userDoc.data().cart || [];
            
            const updatedCart = cart.filter(item => item.id !== productId);
            await updateDoc(userRef, { cart: updatedCart });
            
            console.log('Item removed from cart in Firebase');
            return updatedCart;
        } catch (error) {
            console.error('Error removing from cart in Firebase:', error);
            throw new Error('Ошибка при удалении из корзины: ' + error.message);
        }
    }

    async updateCartItemQuantity(productId, quantity) {
        console.log('Updating cart item quantity:', productId, quantity);
        
        if (!this.currentUser) {
            console.log('No user, using local cart');
            return this.updateLocalCartItemQuantity(productId, quantity);
        }

        try {
            const userRef = doc(db, 'users', this.currentUser.uid);
            const userDoc = await getDoc(userRef);
            const cart = userDoc.data().cart || [];
            
            const updatedCart = cart.map(item => 
                item.id === productId ? { ...item, quantity } : item
            );
            
            await updateDoc(userRef, { cart: updatedCart });
            console.log('Cart item quantity updated in Firebase');
            return updatedCart;
        } catch (error) {
            console.error('Error updating cart item quantity in Firebase:', error);
            throw new Error('Ошибка при обновлении количества: ' + error.message);
        }
    }

    getLocalCart() {
        try {
            const cart = JSON.parse(localStorage.getItem('cart')) || [];
            console.log('Local cart retrieved:', cart);
            return cart;
        } catch (error) {
            console.error('Error getting local cart:', error);
            return [];
        }
    }

    addToLocalCart(product) {
        try {
            let cart = this.getLocalCart();
            const existingItemIndex = cart.findIndex(item => item.id === product.id);
            
            if (existingItemIndex > -1) {
                cart[existingItemIndex].quantity += 1;
                console.log('Increased quantity in local cart');
            } else {
                cart.push({
                    ...product,
                    quantity: 1,
                    addedAt: new Date()
                });
                console.log('Added new item to local cart');
            }
            
            localStorage.setItem('cart', JSON.stringify(cart));
            console.log('Local cart updated:', cart);
            return cart;
        } catch (error) {
            console.error('Error adding to local cart:', error);
            throw new Error('Ошибка при добавлении в локальную корзину');
        }
    }

    removeFromLocalCart(productId) {
        try {
            let cart = this.getLocalCart();
            cart = cart.filter(item => item.id !== productId);
            localStorage.setItem('cart', JSON.stringify(cart));
            console.log('Item removed from local cart');
            return cart;
        } catch (error) {
            console.error('Error removing from local cart:', error);
            throw new Error('Ошибка при удалении из локальной корзины');
        }
    }

    updateLocalCartItemQuantity(productId, quantity) {
        try {
            let cart = this.getLocalCart();
            const updatedCart = cart.map(item => 
                item.id === productId ? { ...item, quantity } : item
            );
            localStorage.setItem('cart', JSON.stringify(updatedCart));
            console.log('Local cart item quantity updated');
            return updatedCart;
        } catch (error) {
            console.error('Error updating local cart item quantity:', error);
            throw new Error('Ошибка при обновлении локальной корзины');
        }
    }

    getAuthErrorMessage(errorCode) {
        const messages = {
            'auth/invalid-email': 'Неверный формат email',
            'auth/user-disabled': 'Аккаунт отключен',
            'auth/user-not-found': 'Пользователь не найден',
            'auth/wrong-password': 'Неверный пароль',
            'auth/email-already-in-use': 'Email уже используется',
            'auth/weak-password': 'Пароль слишком простой'
        };
        return messages[errorCode] || 'Произошла ошибка при авторизации';
    }

    async clearCart() {
        console.log('Clearing cart');

        if (!this.currentUser) {
            console.log('No user, clearing local cart');
            return this.clearLocalCart();
        }

        try {
            const userRef = doc(db, 'users', this.currentUser.uid);
            await updateDoc(userRef, { cart: [] });
            console.log('Cart cleared in Firebase');
            return [];
        } catch (error) {
            console.error('Error clearing cart in Firebase:', error);
            throw new Error('Ошибка при очистке корзины: ' + error.message);
        }
    }

    clearLocalCart() {
        try {
            localStorage.setItem('cart', JSON.stringify([]));
            console.log('Local cart cleared');
            return [];
        } catch (error) {
            console.error('Error clearing local cart:', error);
            throw new Error('Ошибка при очистке локальной корзины');
        }
    }

    isAuthenticated() {
        return !!this.currentUser;
    }
}

const firebaseService = new FirebaseService();
export default firebaseService;
