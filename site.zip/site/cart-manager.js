// cart-manager.js
import firebaseService from './firebase-service.js';
import { db } from './firebase-config.js';
import { collection, addDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

class CartManager {
    constructor() {
        this.cart = [];
        this.freeDeliveryThreshold = 2000;
        this.deliveryCost = 300;
        this.init();
    }

    async init() {
        console.log('CartManager starting...');

        // Wait for Firebase to be ready
        if (!firebaseService) {
            console.error('Firebase service not available');
            return;
        }

        // Wait for DOM to be fully loaded
        if (document.readyState === 'loading') {
            await new Promise(resolve => {
                document.addEventListener('DOMContentLoaded', resolve);
            });
        }

        // Wait for Firebase auth to be initialized
        await this.waitForFirebaseReady();

        try {
            await this.loadCart();
            this.setupEventListeners();
            this.setupVisibilityChangeListener();
            this.renderCart();
            this.updateCartCounter();
            this.loadRecommendedProducts();
            console.log('CartManager initialized successfully. Cart items:', this.cart.length);
        } catch (error) {
            console.error('Error initializing CartManager:', error);
        }
    }

    async waitForFirebaseReady() {
        console.log('Waiting for Firebase to be ready...');

        // Wait for Firebase service to be fully initialized
        let attempts = 0;
        const maxAttempts = 50; // 5 seconds max wait

        while (attempts < maxAttempts) {
            if (firebaseService.currentUser !== undefined) {
                console.log('Firebase is ready');
                return;
            }

            await new Promise(resolve => setTimeout(resolve, 100));
            attempts++;
        }

        console.warn('Firebase initialization timeout, proceeding anyway');
    }

    async loadCart() {
        try {
            console.log('Loading cart from Firebase...');
            this.cart = await firebaseService.getCart();
            console.log('Cart loaded successfully:', this.cart);
        } catch (error) {
            console.error('Error loading cart:', error);
            this.cart = [];
        }
    }

    setupEventListeners() {
        console.log('Setting up cart event listeners...');

        const applyPromoBtn = document.getElementById('apply-promo');
        if (applyPromoBtn) {
            console.log('Apply promo button found');
            applyPromoBtn.addEventListener('click', () => this.applyPromoCode());
        } else {
            console.log('Apply promo button not found');
        }

        const promoCodeInput = document.getElementById('promo-code');
        if (promoCodeInput) {
            console.log('Promo code input found');
            promoCodeInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.applyPromoCode();
                }
            });
        } else {
            console.log('Promo code input not found');
        }

        const checkoutButton = document.getElementById('checkout-button');
        if (checkoutButton) {
            console.log('Checkout button found');
            checkoutButton.addEventListener('click', () => this.handleCheckout());
        } else {
            console.log('Checkout button not found');
        }

        console.log('Cart event listeners setup complete');
    }

    setupCartItemListeners() {
        console.log('Setting up cart item listeners...');

        // Use event delegation on the cart container instead of individual listeners
        const cartContainer = document.getElementById('cart-items-container');
        if (cartContainer) {
            // Remove existing listener to avoid duplicates
            cartContainer.removeEventListener('click', this.handleCartContainerClick);

            // Add new listener using event delegation
            cartContainer.addEventListener('click', this.handleCartContainerClick.bind(this));
            console.log('Cart container event listener attached');
        } else {
            console.error('Cart container not found for event delegation');
        }

        console.log('Cart item listeners setup complete');
    }

    async handleCartContainerClick(e) {
        try {
            const target = e.target;
            const productId = target.getAttribute('data-product-id');

            console.log('Cart container clicked:', target.className, 'data-product-id:', productId);

            if (!productId) return; // Not a cart button

            e.preventDefault();
            e.stopPropagation();

            if (target.classList.contains('increase-quantity')) {
                console.log('Handling increase quantity');
                await this.handleQuantityChangeDirect(productId, 1);
            } else if (target.classList.contains('decrease-quantity')) {
                console.log('Handling decrease quantity');
                await this.handleQuantityChangeDirect(productId, -1);
            } else if (target.classList.contains('remove-item')) {
                console.log('Handling remove item');
                await this.removeItemFromCart(productId);
            }
        } catch (error) {
            console.error('Error in cart container handler:', error);
            this.showNotification('Ошибка: ' + error.message, 'error');
        }
    }



    async handleQuantityChangeDirect(productId, change) {
        const cartItem = this.cart.find(item => item.id === productId);
        if (!cartItem) return;

        const newQuantity = cartItem.quantity + change;

        if (newQuantity < 1) {
            await this.removeItemFromCart(productId);
            return;
        }

        await this.updateItemQuantity(productId, newQuantity);
    }

    setupVisibilityChangeListener() {
        document.addEventListener('visibilitychange', async () => {
            if (!document.hidden) {
                console.log('Page became visible, refreshing cart...');
                await this.loadCart();
                this.renderCart();
                this.updateCartCounter();
            }
        });
    }



    async updateItemQuantity(productId, quantity) {
        try {
            await firebaseService.updateCartItemQuantity(productId, quantity);
            await this.loadCart();
            this.renderCart();
            this.updateCartCounter();
        } catch (error) {
            this.showNotification('Ошибка при обновлении количества: ' + error.message, 'error');
        }
    }

    async removeItemFromCart(productId) {
        try {
            await firebaseService.removeFromCart(productId);
            await this.loadCart();
            this.renderCart();
            this.updateCartCounter();
        } catch (error) {
            this.showNotification('Ошибка при удалении товара: ' + error.message, 'error');
        }
    }

    renderCart() {
        const container = document.getElementById('cart-items-container');
        const emptyMessage = document.getElementById('empty-cart-message');
        const checkoutButton = document.getElementById('checkout-button');
        const deliveryProgress = document.getElementById('delivery-progress');

        if (!container) {
            console.error('Cart container not found!');
            return;
        }

        console.log('Rendering cart with', this.cart.length, 'items');

        if (this.cart.length === 0) {
            container.innerHTML = '';
            if (emptyMessage) emptyMessage.classList.remove('hidden');
            if (checkoutButton) checkoutButton.classList.add('hidden');
            if (deliveryProgress) deliveryProgress.classList.add('hidden');
            this.updateCartSummary();
            console.log('Cart is empty');
            return;
        }

        if (emptyMessage) emptyMessage.classList.add('hidden');
        if (checkoutButton) checkoutButton.classList.remove('hidden');
        if (deliveryProgress) deliveryProgress.classList.remove('hidden');

        container.innerHTML = this.cart.map(item => {
            // Используем fullPrice если доступен, иначе парсим из строки цены
            const fullPrice = item.fullPrice || this.extractPrice(item.price) || 0;
            const totalPrice = fullPrice * item.quantity;

            return `
            <div class="cart-item bg-gray-50 rounded-lg p-4 flex flex-col sm:flex-row gap-4" data-product-id="${item.id}">
                <img src="${item.image}" alt="${item.name}"
                     class="w-full sm:w-24 h-24 object-cover rounded-lg flex-shrink-0">

                <div class="flex-1">
                    <h3 class="font-semibold text-lg mb-1">${item.name}</h3>
                    <p class="text-gray-600 text-sm mb-2">${item.description || ''}</p>
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-2">
                            <button class="decrease-quantity w-8 h-8 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors"
                                    data-product-id="${item.id}" type="button">-</button>
                            <span class="quantity-display w-8 text-center font-semibold">${item.quantity}</span>
                            <button class="increase-quantity w-8 h-8 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors"
                                    data-product-id="${item.id}" type="button">+</button>
                        </div>
                        <div class="text-right">
                            <div class="text-lg font-bold text-pink-600 item-total">
                                ${totalPrice.toLocaleString('ru-RU')} ₽
                            </div>
                            <div class="text-sm text-gray-500">
                                ${fullPrice.toLocaleString('ru-RU')} ₽/шт
                            </div>
                        </div>
                    </div>
                </div>

                <button class="remove-item text-red-500 hover:text-red-700 p-2 self-start sm:self-center"
                        data-product-id="${item.id}" title="Удалить" type="button">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                    </svg>
                </button>
            </div>
            `;
        }).join('');

        // Re-setup event listeners after rendering new buttons
        this.setupCartItemListeners();

        this.updateCartSummary();
        this.updateDeliveryProgress();
    }

    // Новый метод: извлечение цены из строки
    extractPrice(priceString) {
        if (!priceString) return 0;
        // Убираем все нецифровые символы кроме точки и запятой
        const cleanPrice = priceString.replace(/[^\d,.]/g, '').replace(',', '.');
        return parseFloat(cleanPrice) || 0;
    }

    updateCartSummary() {
        const subtotal = this.cart.reduce((sum, item) => {
            const fullPrice = item.fullPrice || this.extractPrice(item.price) || 0;
            return sum + (fullPrice * item.quantity);
        }, 0);
        
        const delivery = subtotal >= this.freeDeliveryThreshold ? 0 : this.deliveryCost;
        const total = subtotal + delivery;

        const subtotalElement = document.getElementById('subtotal-amount');
        const deliveryElement = document.getElementById('delivery-cost');
        const totalElement = document.getElementById('total-amount');
        const itemsCountElement = document.getElementById('cart-items-count');

        if (subtotalElement) subtotalElement.textContent = `${subtotal.toLocaleString('ru-RU')} ₽`;
        if (deliveryElement) deliveryElement.textContent = delivery === 0 ? 'Бесплатно' : `${delivery.toLocaleString('ru-RU')} ₽`;
        if (totalElement) totalElement.textContent = `${total.toLocaleString('ru-RU')} ₽`;
        
        if (itemsCountElement) {
            const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
            itemsCountElement.textContent = `${totalItems} ${this.getItemsWord(totalItems)}`;
        }
    }

    updateDeliveryProgress() {
        const subtotal = this.cart.reduce((sum, item) => {
            const fullPrice = item.fullPrice || this.extractPrice(item.price) || 0;
            return sum + (fullPrice * item.quantity);
        }, 0);
        
        const progress = Math.min((subtotal / this.freeDeliveryThreshold) * 100, 100);
        const remaining = Math.max(this.freeDeliveryThreshold - subtotal, 0);

        const progressBar = document.getElementById('delivery-progress-bar');
        const deliveryAmount = document.getElementById('free-delivery-amount');

        if (progressBar) progressBar.style.width = `${progress}%`;
        if (deliveryAmount) deliveryAmount.textContent = `${remaining.toLocaleString('ru-RU')} ₽`;
    }

    updateCartCounter() {
        const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
        const cartCountElement = document.getElementById('cart-count');
        
        if (cartCountElement) {
            cartCountElement.textContent = totalItems > 0 ? `(${totalItems})` : '';
        }
    }

    applyPromoCode() {
        const promoInput = document.getElementById('promo-code');
        const promoCode = promoInput.value.trim().toUpperCase();
        
        if (!promoCode) {
            this.showNotification('Введите промокод', 'error');
            return;
        }

        const promoCodes = {
            'WELCOME10': 0.1,
            'FIRSTORDER': 0.15,
            'FREEDELIVERY': 'free_delivery'
        };

        if (promoCodes[promoCode]) {
            this.showNotification('Промокод применен!', 'success');
            if (promoInput) promoInput.disabled = true;
            const applyBtn = document.getElementById('apply-promo');
            if (applyBtn) applyBtn.disabled = true;
        } else {
            this.showNotification('Неверный промокод', 'error');
        }
    }

    async handleCheckout() {
        if (this.cart.length === 0) {
            this.showNotification('Корзина пуста', 'error');
            return;
        }

        // Проверяем авторизацию
        if (!firebaseService.isAuthenticated()) {
            this.showNotification('Для оформления заказа необходимо войти в систему', 'error');
            // Показываем модальное окно авторизации
            const authModal = document.getElementById('auth-modal');
            if (authModal) {
                authModal.classList.remove('hidden');
            }
            return;
        }

        // Показываем форму оформления заказа
        this.showCheckoutForm();
    }

    showCheckoutForm() {
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4 max-h-[90vh] overflow-y-auto">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-bold">Оформление заказа</h3>
                    <button id="close-checkout" class="text-gray-500 hover:text-gray-700 text-2xl">&times;</button>
                </div>

                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Имя *</label>
                        <input type="text" id="checkout-name" class="w-full p-2 border rounded focus:ring-2 focus:ring-pink-500" required>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Телефон *</label>
                        <input type="tel" id="checkout-phone" class="w-full p-2 border rounded focus:ring-2 focus:ring-pink-500" required>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                        <input type="email" id="checkout-email" class="w-full p-2 border rounded focus:ring-2 focus:ring-pink-500"
                               value="${firebaseService.currentUser?.email || ''}" required>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Адрес доставки *</label>
                        <textarea id="checkout-address" rows="3" class="w-full p-2 border rounded focus:ring-2 focus:ring-pink-500" required></textarea>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Комментарий к заказу</label>
                        <textarea id="checkout-comment" rows="2" class="w-full p-2 border rounded focus:ring-2 focus:ring-pink-500" placeholder="Необязательно"></textarea>
                    </div>

                    <div class="border-t pt-4">
                        <h4 class="font-semibold mb-2">Ваш заказ:</h4>
                        <div id="checkout-items" class="space-y-1 text-sm">
                            <!-- Товары будут здесь -->
                        </div>
                        <div class="border-t mt-2 pt-2 font-semibold">
                            <div class="flex justify-between">
                                <span>Итого:</span>
                                <span id="checkout-total">0 ₽</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="flex gap-3 mt-6">
                    <button id="confirm-order" class="flex-1 bg-pink-500 text-white py-2 rounded hover:bg-pink-600 transition-colors">
                        Подтвердить заказ
                    </button>
                    <button id="cancel-checkout" class="flex-1 bg-gray-500 text-white py-2 rounded hover:bg-gray-600 transition-colors">
                        Отмена
                    </button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        // Заполняем товары в форме
        this.populateCheckoutItems();

        // Обработчики событий
        document.getElementById('close-checkout').addEventListener('click', () => modal.remove());
        document.getElementById('cancel-checkout').addEventListener('click', () => modal.remove());
        document.getElementById('confirm-order').addEventListener('click', () => this.confirmOrder(modal));
    }

    populateCheckoutItems() {
        const container = document.getElementById('checkout-items');
        const totalElement = document.getElementById('checkout-total');

        container.innerHTML = this.cart.map(item => {
            const fullPrice = item.fullPrice || this.extractPrice(item.price) || 0;
            const totalPrice = fullPrice * item.quantity;
            return `<div class="flex justify-between">
                <span>${item.name} (${item.quantity} шт.)</span>
                <span>${totalPrice.toLocaleString('ru-RU')} ₽</span>
            </div>`;
        }).join('');

        const subtotal = this.cart.reduce((sum, item) => {
            const fullPrice = item.fullPrice || this.extractPrice(item.price) || 0;
            return sum + (fullPrice * item.quantity);
        }, 0);

        const delivery = subtotal >= this.freeDeliveryThreshold ? 0 : this.deliveryCost;
        const total = subtotal + delivery;

        totalElement.textContent = `${total.toLocaleString('ru-RU')} ₽`;
    }

    async confirmOrder(modal) {
        const name = document.getElementById('checkout-name').value.trim();
        const phone = document.getElementById('checkout-phone').value.trim();
        const email = document.getElementById('checkout-email').value.trim();
        const address = document.getElementById('checkout-address').value.trim();
        const comment = document.getElementById('checkout-comment').value.trim();

        if (!name || !phone || !email || !address) {
            this.showNotification('Заполните все обязательные поля', 'error');
            return;
        }

        try {
            // Создаем заказ
            const subtotal = this.cart.reduce((sum, item) => {
                const fullPrice = item.fullPrice || this.extractPrice(item.price) || 0;
                return sum + (fullPrice * item.quantity);
            }, 0);

            const deliveryCost = subtotal >= this.freeDeliveryThreshold ? 0 : this.deliveryCost;

            const order = {
                id: 'order-' + Date.now(),
                userId: firebaseService.currentUser.uid,
                userEmail: firebaseService.currentUser.email,
                customerInfo: { name, phone, email, address, comment },
                items: this.cart,
                subtotal: subtotal,
                deliveryCost: deliveryCost,
                total: subtotal + deliveryCost,
                status: 'pending',
                createdAt: new Date(),
                updatedAt: new Date()
            };

            // Сохраняем заказ в Firebase
            await this.saveOrder(order);

            // Очищаем корзину
            await firebaseService.clearCart();
            await this.loadCart();
            this.renderCart();
            this.updateCartCounter();

            modal.remove();
            this.showNotification('Заказ успешно оформлен! Мы свяжемся с вами в ближайшее время.', 'success');

        } catch (error) {
            console.error('Error creating order:', error);
            this.showNotification('Ошибка при оформлении заказа: ' + error.message, 'error');
        }
    }

    async saveOrder(order) {
        try {
            await addDoc(collection(db, 'orders'), order);
            console.log('Order saved successfully:', order.id);
        } catch (error) {
            console.error('Error saving order:', error);
            throw new Error('Не удалось сохранить заказ');
        }
    }

    loadRecommendedProducts() {
        const container = document.getElementById('recommended-products');
        if (!container) return;

        const recommendedProducts = [
            {
                name: "Лакомство для кошек",
                price: "299 ₽",
                image: "images/mish1.png",
                fullPrice: 299
            },
            {
                name: "Шампунь для собак",
                price: "599 ₽",
                image: "images/kost1.png",
                fullPrice: 599
            }
        ];

        container.innerHTML = recommendedProducts.map(product => `
            <article class="bg-white rounded-lg p-4 shadow-md hover:shadow-lg transition-shadow">
                <img src="${product.image}" alt="${product.name}" 
                     class="w-full aspect-[3/3] object-cover rounded-md mb-3">
                <h3 class="text-base font-semibold mb-2">${product.name}</h3>
                <div class="flex justify-between items-center">
                    <span class="text-lg font-bold text-pink-600">${product.price}</span>
                    <button class="add-recommended bg-pink-500 text-white px-4 py-2 rounded-lg hover:bg-pink-600 transition-colors text-sm" 
                            data-product='${JSON.stringify(product).replace(/'/g, "&apos;")}'>
                        В корзину
                    </button>
                </div>
            </article>
        `).join('');

        document.querySelectorAll('.add-recommended').forEach(button => {
            button.addEventListener('click', async (e) => {
                const productData = JSON.parse(e.target.getAttribute('data-product'));
                await this.addRecommendedToCart(productData);
            });
        });
    }

    async addRecommendedToCart(productData) {
        const product = {
            id: 'rec-' + Date.now(),
            name: productData.name,
            price: productData.price,
            fullPrice: productData.fullPrice,
            image: productData.image,
            description: 'Рекомендуемый товар',
            category: 'рекомендации',
            quantity: 1
        };

        try {
            await firebaseService.addToCart(product);
            await this.loadCart();
            this.renderCart();
            this.showNotification(`Товар "${product.name}" добавлен в корзину!`, 'success');
        } catch (error) {
            this.showNotification('Ошибка при добавлении в корзину: ' + error.message, 'error');
        }
    }

    getItemsWord(count) {
        if (count % 10 === 1 && count % 100 !== 11) return 'товар';
        if ([2, 3, 4].includes(count % 10) && ![12, 13, 14].includes(count % 100)) return 'товара';
        return 'товаров';
    }


}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    new CartManager();
});