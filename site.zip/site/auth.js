// auth.js
import firebaseService from './firebase-service.js';

class AuthManager {
    constructor() {
        this.init();
    }

    init() {
        this.createAuthModal();
        this.setupEventListeners();
    }

    createAuthModal() {
        if (!document.getElementById('auth-modal')) {
            const modalHTML = `
                <div id="auth-modal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
                    <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-xl font-bold" id="auth-title">Вход</h3>
                            <button id="close-auth" class="text-gray-500 hover:text-gray-700 text-xl">&times;</button>
                        </div>
                        <form id="auth-form">
                            <div class="mb-4">
                                <input type="email" id="auth-email" placeholder="Email" 
                                       class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent" required>
                            </div>
                            <div class="mb-4">
                                <input type="password" id="auth-password" placeholder="Пароль" 
                                       class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent" required>
                            </div>
                            <button type="submit" class="w-full bg-pink-500 text-white p-3 rounded-lg hover:bg-pink-600 transition-colors font-semibold">
                                <span id="auth-submit-text">Войти</span>
                            </button>
                        </form>
                        <button id="switch-auth-mode" class="w-full mt-4 text-pink-500 hover:text-pink-700 font-medium">
                            Нет аккаунта? Зарегистрироваться
                        </button>
                        <div id="auth-message" class="mt-4 p-3 rounded-lg hidden text-center"></div>
                    </div>
                </div>
            `;
            document.body.insertAdjacentHTML('beforeend', modalHTML);
        }
    }

    setupEventListeners() {
        document.addEventListener('click', (e) => {
            if (e.target.closest('#auth-button')) {
                if (firebaseService.isAuthenticated()) {
                    this.signOut();
                } else {
                    this.showAuthModal();
                }
            }
        });

        const closeAuth = document.getElementById('close-auth');
        const switchAuth = document.getElementById('switch-auth-mode');
        const authForm = document.getElementById('auth-form');

        if (closeAuth) closeAuth.addEventListener('click', () => this.hideAuthModal());
        if (switchAuth) switchAuth.addEventListener('click', () => this.switchAuthMode());
        if (authForm) authForm.addEventListener('submit', (e) => this.handleAuthSubmit(e));

        document.addEventListener('click', (e) => {
            if (e.target.id === 'auth-modal') {
                this.hideAuthModal();
            }
        });
    }

    showAuthModal() {
        const modal = document.getElementById('auth-modal');
        if (modal) {
            modal.classList.remove('hidden');
            document.getElementById('auth-email').focus();
        }
    }

    hideAuthModal() {
        const modal = document.getElementById('auth-modal');
        if (modal) {
            modal.classList.add('hidden');
            this.resetAuthForm();
        }
    }

    switchAuthMode() {
        const title = document.getElementById('auth-title');
        const submitText = document.getElementById('auth-submit-text');
        const switchButton = document.getElementById('switch-auth-mode');

        if (title.textContent === 'Вход') {
            title.textContent = 'Регистрация';
            submitText.textContent = 'Зарегистрироваться';
            switchButton.textContent = 'Есть аккаунт? Войти';
        } else {
            title.textContent = 'Вход';
            submitText.textContent = 'Войти';
            switchButton.textContent = 'Нет аккаунта? Зарегистрироваться';
        }

        this.hideMessage();
    }

    async handleAuthSubmit(e) {
        e.preventDefault();
        
        const email = document.getElementById('auth-email').value;
        const password = document.getElementById('auth-password').value;
        const isLogin = document.getElementById('auth-title').textContent === 'Вход';

        try {
            if (isLogin) {
                await firebaseService.signIn(email, password);
                this.showMessage('Вход выполнен успешно!', 'success');
            } else {
                await firebaseService.signUp(email, password);
                this.showMessage('Регистрация прошла успешно!', 'success');
            }
            setTimeout(() => this.hideAuthModal(), 1500);
        } catch (error) {
            this.showMessage(error.message, 'error');
        }
    }

    async signOut() {
        try {
            await firebaseService.signOut();
            this.showNotification('Вы вышли из системы');
        } catch (error) {
            this.showNotification('Ошибка при выходе: ' + error.message, 'error');
        }
    }

    showMessage(text, type) {
        const messageEl = document.getElementById('auth-message');
        if (messageEl) {
            messageEl.textContent = text;
            messageEl.className = `mt-4 p-3 rounded-lg text-center ${
                type === 'error' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
            }`;
            messageEl.classList.remove('hidden');
        }
    }

    hideMessage() {
        const messageEl = document.getElementById('auth-message');
        if (messageEl) {
            messageEl.classList.add('hidden');
        }
    }

    resetAuthForm() {
        const form = document.getElementById('auth-form');
        if (form) form.reset();
        this.hideMessage();
    }


}

document.addEventListener('DOMContentLoaded', () => {
    new AuthManager();
});