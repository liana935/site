// app.js
import firebaseService from './firebase-service.js';
import { showNotification, updateCartCountElement, updateCartCounter } from './utils.js';

class ZooShopApp {
    constructor() {
        this.init();
    }

    init() {
        this.initCart();
        this.initEventListeners();
        this.initSearch();
        console.log('ZooShopApp initialized');
    }

    initCart() {
        this.updateCartCounter();
    }

    initEventListeners() {
        // Only add cart listeners if we're not on the cart page
        if (!document.body.classList.contains('cart-page')) {
            document.addEventListener('click', (e) => {
                const cartBtn = e.target.closest('.cart-btn');
                const pinkBtn = e.target.closest('.bg-pink-500');

                if (cartBtn || (pinkBtn && pinkBtn.textContent.includes('корзин'))) {
                    this.handleAddToCart(e);
                }
            });
        }

        const catalogBtn = document.querySelector('a[href="catalog.html"]');
        if (catalogBtn) {
            catalogBtn.addEventListener('click', (e) => {
                e.preventDefault();
                window.location.href = 'catalog.html';
            });
        }
    }

    initSearch() {
        const searchInput = document.getElementById('search-input');
        const searchButton = document.getElementById('search-button');
        const searchResults = document.getElementById('search-results');

        if (searchInput && searchButton) {
            searchButton.addEventListener('click', () => this.performSearch(searchInput.value));
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.performSearch(searchInput.value);
                }
            });
        }

        const closeSearch = document.getElementById('close-search');
        if (closeSearch) {
            closeSearch.addEventListener('click', () => this.hideSearchResults());
        }
    }

    async performSearch(query) {
        if (!query.trim()) {
            this.hideSearchResults();
            return;
        }

        const searchResults = document.getElementById('search-results');
        const searchResultsGrid = document.getElementById('search-results-grid');
        const noResults = document.getElementById('no-results');
        const bestOffersSection = document.querySelector('.bg-pink-100');

        try {
            const products = await firebaseService.searchProducts(query);
            
            searchResultsGrid.innerHTML = '';
            
            if (products.length === 0) {
                noResults.classList.remove('hidden');
                searchResultsGrid.classList.add('hidden');
            } else {
                noResults.classList.add('hidden');
                searchResultsGrid.classList.remove('hidden');
                
                    products.forEach(product => {
                        const productElement = document.createElement('article');
                        productElement.className = 'product-card bg-white rounded-lg p-4 shadow-md hover:shadow-lg transition-shadow';
                        productElement.setAttribute('data-category', product.category);
                        productElement.setAttribute('data-price', product.fullPrice);
                        productElement.setAttribute('data-product-id', product.id);
                        productElement.innerHTML = `
                            <img src="${product.image}" alt="${product.name}" class="w-full aspect-[3/3] object-cover rounded-md mb-3">
                            <h3 class="text-base font-semibold mb-2 truncate">${product.name}</h3>
                            <p class="text-gray-600 text-sm mb-3 line-clamp-2">${product.description}</p>
                            <div class="flex justify-between items-center">
                                <span class="text-lg font-bold text-pink-600">${product.price}</span>
                                <button class="cart-btn bg-pink-500 text-white px-4 py-2 rounded-lg hover:bg-pink-600 transition-colors text-sm">
                                    В корзину
                                </button>
                            </div>
                        `;
                        searchResultsGrid.appendChild(productElement);
                    });
            }

            searchResults.classList.add('active');
            if (bestOffersSection) {
                bestOffersSection.style.display = 'none';
            }
            
            searchResults.scrollIntoView({ behavior: 'smooth' });

        } catch (error) {
            console.error('Search error:', error);
        }
    }

    hideSearchResults() {
        const searchResults = document.getElementById('search-results');
        const bestOffersSection = document.querySelector('.bg-pink-100');
        const searchInput = document.getElementById('search-input');

        if (searchResults) {
            searchResults.classList.remove('active');
        }
        if (bestOffersSection) {
            bestOffersSection.style.display = 'block';
        }
        if (searchInput) {
            searchInput.value = '';
        }
    }

    async handleAddToCart(e) {
        e.preventDefault();

        const button = e.target.closest('.cart-btn') || e.target.closest('.bg-pink-500');
        const productCard = button.closest('.product-card') || button.closest('article');

        if (!productCard) {
            console.error('Product card not found');
            return;
        }

        // Get product ID from data attribute first
        let productId = productCard.getAttribute('data-product-id');

        if (!productId) {
            // Fallback to generating ID if not found (for dynamically created cards)
            productId = this.generateProductId(productCard);
        }

        const productName = productCard.querySelector('h3')?.textContent;
        const productPrice = productCard.querySelector('.text-pink-600')?.textContent;
        const productImage = productCard.querySelector('img')?.src;
        const productDescription = productCard.querySelector('p')?.textContent || '';
        const productCategory = productCard.getAttribute('data-category') || 'other';
        const productFullPrice = parseInt(productCard.getAttribute('data-price')) || 0;

        const productData = {
            id: productId,
            name: productName,
            price: productPrice,
            image: productImage,
            description: productDescription,
            category: productCategory,
            fullPrice: productFullPrice
        };

        console.log('Adding product to cart:', productData);

        try {
            await firebaseService.addToCart(productData);
            await this.updateCartCounter();
            this.showNotification(`Товар "${productData.name}" добавлен в корзину!`);

            const updatedCart = await firebaseService.getCart();
            console.log('Cart after addition:', updatedCart);
        } catch (error) {
            console.error('Error adding to cart:', error);
            this.showNotification(error.message, 'error');
        }
    }

    generateProductId(element) {
        const name = element.querySelector('h3')?.textContent || 'product';
        return name.toLowerCase().replace(/[^a-z0-9]/g, '-') + '-' + Date.now();
    }

    async updateCartCounter() {
        await updateCartCounter(firebaseService);
    }
}

window.handleAuthChange = (user) => {
    const authButton = document.getElementById('auth-button');
    if (authButton) {
        if (user) {
            authButton.textContent = user.email;
            authButton.setAttribute('title', 'Нажмите для выхода');
        } else {
            authButton.textContent = 'ВХОД/РЕГИСТРАЦИЯ';
            authButton.removeAttribute('title');
        }
    }

    if (window.zooShopApp) {
        window.zooShopApp.updateCartCounter();
    }
};

document.addEventListener('DOMContentLoaded', () => {
    window.zooShopApp = new ZooShopApp();
});