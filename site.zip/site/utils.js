// utils.js - Utility functions for the application

// Show notification to user
export function showNotification(message, type = 'success') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());

    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg transition-all duration-300 transform translate-x-full`;

    if (type === 'success') {
        notification.classList.add('bg-green-500', 'text-white');
    } else if (type === 'error') {
        notification.classList.add('bg-red-500', 'text-white');
    } else if (type === 'warning') {
        notification.classList.add('bg-yellow-500', 'text-black');
    } else {
        notification.classList.add('bg-blue-500', 'text-white');
    }

    notification.innerHTML = `
        <div class="flex items-center">
            <span class="flex-1">${message}</span>
            <button class="ml-4 text-xl font-bold hover:opacity-75" onclick="this.parentElement.parentElement.remove()">&times;</button>
        </div>
    `;

    document.body.appendChild(notification);

    // Animate in
    setTimeout(() => {
        notification.classList.remove('translate-x-full');
    }, 100);

    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.classList.add('translate-x-full');
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

// Update cart counter element
export function updateCartCountElement(count) {
    const cartCountElement = document.getElementById('cart-count');
    if (cartCountElement) {
        cartCountElement.textContent = count > 0 ? `(${count})` : '';
    }
}

// Update cart counter from Firebase service
export async function updateCartCounter(firebaseService) {
    try {
        const cart = await firebaseService.getCart();
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        updateCartCountElement(totalItems);
        console.log('Cart counter updated:', totalItems);
    } catch (error) {
        console.error('Error updating cart counter:', error);
        updateCartCountElement(0);
    }
}

// Format price
export function formatPrice(price) {
    if (typeof price === 'string') {
        return price;
    }
    return `${price.toLocaleString('ru-RU')} ₽`;
}

// Extract price from string
export function extractPrice(priceString) {
    if (!priceString) return 0;
    const cleanPrice = priceString.replace(/[^\d,.]/g, '').replace(',', '.');
    return parseFloat(cleanPrice) || 0;
}

// Debounce function
export function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Validate email
export function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Validate phone number (Russian format)
export function validatePhone(phone) {
    const re = /^(\+7|8)?[\s\-]?\(?[0-9]{3}\)?[\s\-]?[0-9]{3}[\s\-]?[0-9]{2}[\s\-]?[0-9]{2}$/;
    return re.test(phone);
}

// Get category name in Russian
export function getCategoryName(category) {
    const categories = {
        'кошки': 'Для кошек',
        'собаки': 'Для собак',
        'рыбы': 'Для рыб',
        'грызуны': 'Для грызунов'
    };
    return categories[category] || category;
}

// Generate unique ID
export function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Check if user is authenticated
export function isAuthenticated() {
    return !!window.firebaseService?.currentUser;
}

// Get current user
export function getCurrentUser() {
    return window.firebaseService?.currentUser || null;
}

// Show loading spinner
export function showLoading(element) {
    if (element) {
        element.innerHTML = `
            <div class="flex justify-center items-center py-8">
                <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-pink-500"></div>
                <span class="ml-2 text-gray-600">Загрузка...</span>
            </div>
        `;
    }
}

// Hide loading spinner
export function hideLoading(element) {
    if (element && element.querySelector('.animate-spin')) {
        element.innerHTML = '';
    }
}

// Scroll to element smoothly
export function scrollToElement(element, offset = 0) {
    if (element) {
        const elementPosition = element.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - offset;

        window.scrollTo({
            top: offsetPosition,
            behavior: 'smooth'
        });
    }
}

// Copy text to clipboard
export async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        showNotification('Скопировано в буфер обмена', 'success');
    } catch (error) {
        console.error('Failed to copy:', error);
        showNotification('Не удалось скопировать', 'error');
    }
}

// Format date
export function formatDate(date) {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleDateString('ru-RU', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Format date and time
export function formatDateTime(date) {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleString('ru-RU', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Get order status in Russian
export function getOrderStatus(status) {
    const statuses = {
        'pending': 'Ожидает обработки',
        'processing': 'В обработке',
        'shipped': 'Отправлен',
        'delivered': 'Доставлен',
        'cancelled': 'Отменен'
    };
    return statuses[status] || status;
}

// Calculate discount percentage
export function calculateDiscount(originalPrice, discountedPrice) {
    if (originalPrice <= 0) return 0;
    return Math.round(((originalPrice - discountedPrice) / originalPrice) * 100);
}

// Check if element is in viewport
export function isInViewport(element) {
    if (!element) return false;
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

// Lazy load images
export function lazyLoadImages() {
    const images = document.querySelectorAll('img[data-src]');

    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                observer.unobserve(img);
            }
        });
    });

    images.forEach(img => imageObserver.observe(img));
}

// Initialize lazy loading
document.addEventListener('DOMContentLoaded', () => {
    lazyLoadImages();
});
